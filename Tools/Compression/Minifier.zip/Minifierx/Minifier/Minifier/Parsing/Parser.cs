﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Minifier.Parsing
{
    public class Parser
    {
        private static readonly string[] Tokens = new[] {"nil", "or", "and", "<", ">", "<=", ">=", "~=", "==", "..", "+", "-", "*", "/", "%", "^", "=", ","};
        private readonly List<Scope> _scopes = new List<Scope>();

        private string Clean(string lua)
        {
            lua = Regex.Replace(lua, "^function\\s+([^\\(]+)", "$1 = function");
            lua = lua.Trim();
            return lua;
        }

        public object[] Parse(string lua)
        {
            lua = Clean(lua);
            var result = new List<object>();
            do {
                result.Add(ParseNext(lua, out lua));
            } while (result.Last() != null);
            return result.ToArray();
        }

        private object ParseNext(string lua, out string remainder)
        {
            remainder = lua.TrimNext();
            if (string.IsNullOrWhiteSpace(remainder)) return null;
            if (remainder.IsKeyword("if")) return ParseIf(remainder, out remainder);
            if (remainder.IsKeyword("else")) return ParseElse(remainder, out remainder);
            if (remainder.IsKeyword("elseif")) return ParseElseIf(remainder, out remainder);
            if (remainder.IsKeyword("for")) return ParseFor(remainder, out remainder);
            if (remainder.IsKeyword("while")) return ParseWhile(remainder, out remainder);
            if (remainder.IsKeyword("repeat")) return ParseRepeat(remainder, out remainder);
            if (remainder.StartsWith("--")) return ParseComment(remainder, out remainder);
            if (remainder.StartsWith("(")) return ParseParens(remainder, out remainder);
            if (remainder.StartsWith("{")) return ParseTable(remainder, out remainder);
            if (remainder.StartsWith("[")) return ParseIndex(remainder, out remainder);
            if (remainder.StartsWith("\"")) return ParseString(remainder, out remainder);
            if (remainder.StartsWith("'")) return ParseString(remainder, out remainder);
            if (remainder.Matches(@"^-?\d")) return ParseNumber(remainder, out remainder);
            if (remainder.Matches(@"^function\\s*\\(")) return ParseFunction(remainder, out remainder);
            if (Tokens.Any(remainder.IsKeyword))
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minifier.Parsing
{
    public class Scope
    {
        public readonly List<string> Terminators = new List<string>(); 
        public readonly List<Reference> References = new List<Reference>(); 
    }
}

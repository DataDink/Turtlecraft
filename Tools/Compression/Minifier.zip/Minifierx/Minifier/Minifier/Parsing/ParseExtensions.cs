﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Minifier.Parsing
{
    public static class ParseExtensions
    {
        private static Regex Trim = new Regex(@"^[\s;]+", RegexOptions.Compiled | RegexOptions.Singleline);
        public static string TrimNext(this string lua, string phrase = null)
        {
            lua = Trim.Replace(lua, "");
            if (phrase != null) lua = lua.Substring(phrase.Length);
            return Trim.Replace(lua, "");
        }

        public static bool IsKeyword(this string lua, string phrase)
        {
            return Regex.IsMatch(lua, string.Format(@"^{0}(?!\S)"));
        }

        public static bool Matches(this string lua, string pattern)
        {
            return Regex.IsMatch(lua, pattern);
        }
    }
}
